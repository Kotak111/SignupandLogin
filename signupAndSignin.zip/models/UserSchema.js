const { Schema, model } = require("mongoose");
const bcrypt=require("bcryptjs")
const jwt=require("jsonwebtoken")
const UserSchema=new Schema({
    email:{
        type:String,
        unique:true,
        required:true,
        trim:true
    },
    password:{
        type:String,
        required:true,
    },
    otp:{
        type:String,
       
    },
    tokens:[
        {
            token:{
                type:String,
                required:true
            }
        }
    ]
})
UserSchema.pre('save',async function(next){
    if(this.isModified("password")){
        this.password=await bcrypt.hash(this.password,10)
    }
    next();
})

//generating token
UserSchema.methods.generateAuthToken= async function(){
    try{
        let token=jwt.sign({_id:this._id},"swlfcndekdcslm")
        this.tokens=this.tokens.concat({token:token})
        await this.save()
        return token;
    }
    catch(err){
        console.log(err);
    }
}

const User=model("userData",UserSchema)
module.exports=User