const nodemailer=require("nodemailer")

const transPorter=nodemailer.createTransport({
    service:"gmail",
    auth:{
        user:"kotakh311@gmail.com",
        pass:"casv enss rkeh viaw",
    }
})


async function senData(to,otp){
    const mailFormat={
        from:"kotakh311@gmail.com",
        to:to,
        subject:"check mail",
        html:`<h1>Your verification code is:${otp} </h1>`
    }
    await transPorter.sendMail(mailFormat, (err,info)=>{
        if(err){
            console.log(err);
        }
        else{
            console.log("send mail");
        }
    })
}
module.exports=senData