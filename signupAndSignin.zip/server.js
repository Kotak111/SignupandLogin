const express = require('express')
const app = express()
const port = 5000
app.use(express.json())
app.use(express.urlencoded({extended:true}))
require("./config/db")
const UserRoutes=require("./Routes/UserRoute")
// app.use("/api/user",UserRoutes)
app.use("/api/user",UserRoutes)


app.listen(port, () => console.log(`Example app listening on port ${port}!`))